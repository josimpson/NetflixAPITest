package simpson.joseph.NetflixDataTest;

public class Titles {

	private String id;
	private String title;
	private String type;
	private String description;
	private String release_year;
	private String age_certification;
	private String genres;
	private String production_countries;
	private String seasons;
	private String imdb_id;
	private String imdb_score;
	private String imdb_votes;
	private String tmdb_popularity;
	private String tmdb_score;
	
	public Titles(String id, String title, String type, String description, String release_year,
			String age_certification, String genres, String production_countries, String seasons, String imdb_id,
			String imdb_score, String imdb_votes, String tmdb_popularity, String tmdb_score) {
		super();
		this.id = id;
		this.title = title;
		this.type = type;
		this.description = description;
		this.release_year = release_year;
		this.age_certification = age_certification;
		this.genres = genres;
		this.production_countries = production_countries;
		this.seasons = seasons;
		this.imdb_id = imdb_id;
		this.imdb_score = imdb_score;
		this.imdb_votes = imdb_votes;
		this.tmdb_popularity = tmdb_popularity;
		this.tmdb_score = tmdb_score;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getRelease_year() {
		return release_year;
	}

	public void setRelease_year(String release_year) {
		this.release_year = release_year;
	}

	public String getAge_certification() {
		return age_certification;
	}

	public void setAge_certification(String age_certification) {
		this.age_certification = age_certification;
	}

	public String getGenres() {
		return genres;
	}

	public void setGenres(String genres) {
		this.genres = genres;
	}

	public String getProduction_countries() {
		return production_countries;
	}

	public void setProduction_countries(String production_countries) {
		this.production_countries = production_countries;
	}

	public String getSeasons() {
		return seasons;
	}

	public void setSeasons(String seasons) {
		this.seasons = seasons;
	}

	public String getImdb_id() {
		return imdb_id;
	}

	public void setImdb_id(String imdb_id) {
		this.imdb_id = imdb_id;
	}

	public String getImdb_score() {
		return imdb_score;
	}

	public void setImdb_score(String imdb_score) {
		this.imdb_score = imdb_score;
	}

	public String getImdb_votes() {
		return imdb_votes;
	}

	public void setImdb_votes(String imdb_votes) {
		this.imdb_votes = imdb_votes;
	}

	public String getTmdb_popularity() {
		return tmdb_popularity;
	}

	public void setTmdb_popularity(String tmdb_popularity) {
		this.tmdb_popularity = tmdb_popularity;
	}

	public String getTmdb_score() {
		return tmdb_score;
	}

	public void setTmdb_score(String tmdb_score) {
		this.tmdb_score = tmdb_score;
	}
	
	
	
}
