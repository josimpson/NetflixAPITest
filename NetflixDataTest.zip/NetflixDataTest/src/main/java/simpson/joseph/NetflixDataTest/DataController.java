package simpson.joseph.NetflixDataTest;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.jooq.tools.json.JSONObject;
import org.json.JSONArray;
import org.json.JSONException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("")
public class DataController {

	static final String DB_URL = "jdbc:sqlserver://localhost:1433;databaseName=Netflix-Info;user=sa;password=password";
	
	@RequestMapping(path = "/getShowByTitle")
	public JSONArray getShowByTitle(@RequestBody String title) throws SQLException {
		title = title.replace("\"", "").trim();
		String insertSql = "SELECT * FROM titles where title='" + title + "';";
		JSONArray arr =  executeSQL(insertSql);
		return arr;
	}
	
	@RequestMapping(path = "/getActorsByTitle/{title}")
	public JSONArray getActorsByTitle(@PathVariable String title) {
		title = title.replace("\"", "").trim();
		String insertSql = "select * from credits where id IN (select id from titles where title='" + title + "');";
		JSONArray arr =  executeSQL(insertSql);
		return arr;
	}
	
	@RequestMapping(path = "/getMovieByActor/{actor}")
	public JSONArray getMovieByActor(@PathVariable String actor) {
		actor = actor.replace("\"", "").trim();
		String insertSql = "select * from titles where id IN (select id from credits where name='" + actor + "');";
		JSONArray arr =  executeSQL(insertSql);
		return arr;
	}
	
	public JSONArray executeSQL(String statement) {
		String insertSql = statement;
		
		ResultSet resultSet = null;
		JSONArray arr = null;
        try (Connection connection = DriverManager.getConnection(DB_URL);
        		PreparedStatement prepState = connection.prepareStatement(insertSql);) {
        	
        	prepState.execute();
            resultSet = prepState.getResultSet();
            
            arr = convertJson(resultSet);
            
        } catch (SQLException e) {
			e.printStackTrace();
		}
        
        return arr;
	}

	@SuppressWarnings("unchecked")
	private JSONArray convertJson(ResultSet resultSet) throws SQLException {
		ResultSetMetaData md = resultSet.getMetaData();
		int numCols = md.getColumnCount();
		List<String> colNames = IntStream.range(0, numCols)
		  .mapToObj(i -> {
		      try {
		          return md.getColumnName(i + 1);
		      } catch (SQLException e) {
		          e.printStackTrace();
		          return "?";
		      }
		  })
		  .collect(Collectors.toList());

		JSONArray result = new JSONArray();
		while (resultSet.next()) {
		    JSONObject row = new JSONObject();
		    colNames.forEach(cn -> {
		        try {
		            row.put(cn, resultSet.getObject(cn));
		        } catch (JSONException | SQLException e) {
		            e.printStackTrace();
		        }
		    });
		    result.put(row);
		}
		return result;
	}
	
}
