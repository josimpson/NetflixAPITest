package simpson.joseph.NetflixDataTest;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("")
public class DataController {

	static final String DB_URL = "jdbc:sqlserver://localhost:1433;databaseName=Netflix-Info;user=sa;password=password";
	
	@RequestMapping(path = "/getShowByTitle")
	public List<String> getShowByTitle(@RequestBody String title) throws SQLException {
		title = title.replace("\"", "").trim();
		String insertSql = "SELECT * FROM titles where title='" + title + "';";
		return  executeSQL(insertSql, true);
	}
	
	@RequestMapping(path = "/getActorsByTitle/{title}")
	public List<String> getActorsByTitle(@PathVariable String title) {
		title = title.replace("\"", "").trim();
		String insertSql = "select * from credits where id IN (select id from titles where title='" + title + "');";
		 return  executeSQL(insertSql, false);
		
	}
	
	@RequestMapping(path = "/getMovieByActor/{actor}")
	public List<String> getMovieByActor(@PathVariable String actor) {
		actor = actor.replace("\"", "").trim();
		String insertSql = "select * from titles where id IN (select id from credits where name='" + actor + "');";
		return executeSQL(insertSql, true);
	}
	
	public List<String> executeSQL(String statement, Boolean titles) {
		List<String> list = new ArrayList<>();
		ResultSet resultSet = null;
		
        try (Connection connection = DriverManager.getConnection(DB_URL);) {

        	Statement stmt = connection.createStatement();     // Create a Statement object           1 
        	resultSet = stmt.executeQuery(statement);     
        	
            
        	if(titles==true) {
        	while (resultSet.next()) {
        		list.add(resultSet.getString(1));
        		list.add(resultSet.getString(2));
        		list.add(resultSet.getString(3));
        		list.add(resultSet.getString(4));
        		list.add(resultSet.getString(5));
        		list.add(resultSet.getString(6));
        		list.add(resultSet.getString(7));
        		list.add(resultSet.getString(8));
        		list.add(resultSet.getString(9));
        		list.add(resultSet.getString(10));
        		list.add(resultSet.getString(11));
        		list.add(resultSet.getString(12));
        		list.add(resultSet.getString(13));
        		list.add(resultSet.getString(14));
        		
        		resultSet.close();        
        		stmt.close();  
        		}
        	}
        	else {
        		while (resultSet.next()) {
            		list.add(resultSet.getString(1));
            		list.add(resultSet.getString(2));
            		list.add(resultSet.getString(3));
            		list.add(resultSet.getString(4));
            		list.add(resultSet.getString(5));
        		}
        		resultSet.close();
        		stmt.close();  
        	}
        	
        } catch (SQLException e) {
			e.printStackTrace();
		}
        
        
        return list;
	}
}
